package ca.mcgill.cs.swdesign.m5;

/**
 * A day of the week. The week starts on Monday.
 */
public enum Day
{
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
